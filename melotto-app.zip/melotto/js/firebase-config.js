// ============================================================
//  ME LOTTO — Firebase Configuration
//  IMPORTANT: Remplace valè yo ak info Firebase pwojè ou a
// ============================================================
const firebaseConfig = {
  apiKey: "REMPLACE_API_KEY",
  authDomain: "REMPLACE_PROJECT_ID.firebaseapp.com",
  projectId: "REMPLACE_PROJECT_ID",
  storageBucket: "REMPLACE_PROJECT_ID.appspot.com",
  messagingSenderId: "REMPLACE_SENDER_ID",
  appId: "REMPLACE_APP_ID"
};

// Init Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// ============================================================
//  UTILS GLOBAL
// ============================================================
function showToast(msg, type = 'info') {
  let t = document.getElementById('globalToast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'globalToast';
    document.body.appendChild(t);
  }
  t.className = `global-toast toast-${type}`;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3500);
}

function formatDate(ts) {
  if (!ts) return '—';
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleDateString('fr-HT', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function formatTime(ts) {
  if (!ts) return '';
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleTimeString('fr-HT', { hour: '2-digit', minute: '2-digit' });
}

async function getCurrentUser() {
  return new Promise(resolve => auth.onAuthStateChanged(resolve));
}

async function getUserRole(uid) {
  const doc = await db.collection('users').doc(uid).get();
  return doc.exists ? doc.data().role : null;
}
