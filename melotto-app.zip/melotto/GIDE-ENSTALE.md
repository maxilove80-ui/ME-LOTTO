# 📖 GIDE ENSTALE ME LOTTO — Etap pa Etap

## 🔥 ETAP 1 — Kreye Kont Firebase (10 min)

### 1.1 Ale sou firebase.google.com
- Klike **"Get started"**
- Konekte ak kont Google ou
- Klike **"Create a project"**
- Non pwojè: `me-lotto` → Klike Continue
- Dezaktive Google Analytics (opsyonèl) → Klike **Create project**

### 1.2 Aktive Authentication
- Nan meni gòch, klike **Authentication**
- Klike **"Get started"**
- Klike **Email/Password**
- Aktive premye switch la → **Save**

### 1.3 Kreye Firestore Database
- Nan meni gòch, klike **Firestore Database**
- Klike **"Create database"**
- Chwazi **"Start in test mode"** (nou va chanje sa apre)
- Chwazi rejyon: `us-east1` → **Enable**

### 1.4 Jwenn Konfigirasyon Firebase
- Klike ⚙️ (settings) anwo agòch
- Klike **Project settings**
- Desann rive nan **"Your apps"**
- Klike ikòn `</>` (Web)
- Non app: `me-lotto-web` → **Register app**
- **KOPYE tout konfigirasyon an** (firebaseConfig) — ou ap bezwen li

---

## 📝 ETAP 2 — Konfigire Aplikasyon an

### 2.1 Ouvri `js/firebase-config.js`
Ranplase valè sa yo ak valè pwojè Firebase ou a:
```javascript
const firebaseConfig = {
  apiKey: "AI...",           ← Mete valè reyèl ou
  authDomain: "me-lotto-xxx.firebaseapp.com",
  projectId: "me-lotto-xxx",
  storageBucket: "me-lotto-xxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123:web:abc"
};
```

---

## 🔒 ETAP 3 — Mete Règ Sekirite Firestore

1. Ale nan **Firestore** → **Rules**
2. Kopye tout kontni `firestore.rules` nan dosye a
3. Klike **Publish**

---

## 👑 ETAP 4 — Kreye Kont Admin Ou

### 4.1 Kreye imel admin nan Firebase Auth
- **Authentication** → **Users** → **Add user**
- Imel: `admin@melotto.com` (oswa imel ou vle)
- Modpas: yon modpas solid
- Kopye UID li (streng long panyèl la montre)

### 4.2 Kreye dokiman admin nan Firestore
- **Firestore** → **Data** → `+ Start collection`
- Collection ID: `users`
- Document ID: **(kole UID ou kopye a)**
- Ajoute chan sa yo:
  ```
  name:     (string)  "Nom Admin"
  email:    (string)  "admin@melotto.com"
  role:     (string)  "admin"
  active:   (boolean) true
  ```
- Klike **Save**

---

## 🚀 ETAP 5 — Pibliye sou Firebase Hosting (Gratis)

### 5.1 Enstale Firebase CLI (sou Laptop ou)
Telechaje Node.js: https://nodejs.org
Epi nan terminal (CMD / PowerShell):
```bash
npm install -g firebase-tools
firebase login
```

### 5.2 Inisyalize hosting
```bash
cd chemin/dosye/melotto
firebase init hosting
```
Reponn kesyon yo:
- **Which project?** → Chwazi `me-lotto-xxx`
- **Public directory?** → tape `.` (yon pwen) epi Enter
- **Single-page app?** → `N`
- **GitHub auto deploys?** → `N`

### 5.3 Pibliye
```bash
firebase deploy --only hosting
```
📱 **Lyen ou a parèt!** Egzanp: `https://me-lotto-xxx.web.app`

---

## 📱 ETAP 6 — Enstale sou Android tankou App

1. Ouvri lyen sit la nan **Chrome Android**
2. Klike **⋮** (3 pwen) anwo adwat
3. Klike **"Ajoute sou ekran dakèy"** (Add to Home Screen)
4. Klike **"Ajoute"**
5. ✅ App la parèt sou ekran telefòn ou tankou yon app nòmal!

---

## 🏪 ETAP 7 — Kreye Kont Ajan yo

1. Konekte kòm Admin: `https://me-lotto-xxx.web.app`
2. Ale nan onglet **"Ajan"**
3. Klike **"+ Ajoute Ajan Nouvo"**
4. Ranpli: Non, Imel, Modpas, Pwen Vant, Limit Jounen
5. Klike **Sove**

> ⚠️ Pou kreyasyon kont ajan otomatik, ou ka bezwen aktive
> **Cloud Functions** Firebase. Sinon, kreye itilizatè manyèlman
> nan Firebase Auth epi ajoute dokiman nan `users` collection.

---

## 🎯 ETAP 8 — Mete Limit Vant Nimewo

1. Konekte kòm Admin
2. Klike onglet **"Limit Vant"**
3. Chwazi **PICK 3** oswa **PICK 4**
4. Mete limit pou chak nimewo (oswa itilize "Limit Global")
5. Klike **"Sove tout Limit yo"**

---

## 📋 REZIME FONKSYON

| Fonksyon            | Admin | Ajan |
|---------------------|-------|------|
| Wè tout vant        | ✅    | ❌   |
| Kreye/edite ajan    | ✅    | ❌   |
| Mete limit nimewo   | ✅    | ❌   |
| Wè limit nimewo     | ✅    | ✅   |
| Anrejistre vant     | ❌    | ✅   |
| Wè pwòp vant        | ✅    | ✅   |
| Wè tiraj rezilta    | ✅    | ✅   |

---

## 🆘 PWOBLÈM KOMIN

**"Permission denied"** → Verifye règ Firestore yo (Etap 3)
**"User not found"** → Asire UID nan Firestore match Firebase Auth
**App pa chaje** → Verifye firebaseConfig nan `firebase-config.js`
**Ajan pa ka konekte** → Asire `active: true` nan dokiman Firestore ajan an

---

📞 Pou èd, kontakte devlopè ou oswa revize Firebase docs: https://firebase.google.com/docs
